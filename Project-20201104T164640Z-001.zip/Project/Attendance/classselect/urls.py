from django.urls import path
from . import views
urlpatterns = [
    path('', views.select),
    path('select', views.select),
    path('studentlist', views.studentlist)
]