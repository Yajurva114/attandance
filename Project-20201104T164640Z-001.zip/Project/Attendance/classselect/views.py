from django.views.generic import TemplateView
from homepage.models import TLogin, TInformation
from django.shortcuts import render, redirect

import config

class ClassSelectView(TemplateView):
    template_name = "classselect.html"

def select(request):
    username = config.user
    T_Information = TInformation.objects.all()
    for i in T_Information:
        if i.TFirstName == username:
            tclass = str(i.TClass) + i.TSection
            config.tclass += [tclass]
    return render(request, "classselect/classselect.html", {"tclass": config.tclass})

def studentlist(request):
    config.selectedclass = request.GET['selectedclass']
    return redirect('/studentpage')