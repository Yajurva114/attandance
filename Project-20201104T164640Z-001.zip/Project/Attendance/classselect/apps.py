from django.apps import AppConfig


class ClassselectConfig(AppConfig):
    name = 'classselect'
