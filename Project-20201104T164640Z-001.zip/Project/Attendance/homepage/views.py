from homepage.models import TLogin, TInformation
from django.http import HttpResponse
from django.shortcuts import render, redirect

import config

def t_login(request):
    T_Login = TLogin.objects.all()
    return render(request, "homepage/homepage.html", {"t_login": T_Login})

def t_information(request):
    T_Information = TInformation.objects.all()
    return render(request, "homepage/homepage.html", {"t_info" : T_Information})

def auth(request):
    username = request.GET['username']
    password = request.GET['password']
    T_Login = TLogin.objects.all()
    config.user = username
    config.passw = password
    for i in T_Login:
        if i.TUsername == username and i.TPassword == password:
            return redirect("classselect/")
    else:
        return HttpResponse(config.user + config.passw)