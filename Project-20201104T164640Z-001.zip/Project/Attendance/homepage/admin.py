from django.contrib import admin

from .models import TInformation
admin.site.register(TInformation)

from .models import TLogin
admin.site.register(TLogin)