from django.urls import path
from . import views

urlpatterns = [
    path('', views.t_information),
    path('auth', views.auth),
]

