from django.apps import AppConfig


class StudentpageConfig(AppConfig):
    name = 'studentpage'
