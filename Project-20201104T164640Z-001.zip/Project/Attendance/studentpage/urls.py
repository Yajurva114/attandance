from django.urls import path
from . import views

urlpatterns = [
    path('', views.selected_class),
    path('givedate', views.givedate),
    path('submit_',views.submit_)
    ]