from django.shortcuts import render
from studentpage.models import SAttendance, SInformation
import config
from datetime import date
from django.http import HttpResponse

def givedate(request):
    selectedDate = request.GET['date']
    config.selecteddate = selectedDate
    return selectedDate

def selected_class(request):
    S_Information = SInformation.objects.all()
    date_ = date.today()
    today = date_.strftime("%Y-%m-%d")
    selectedclassint = ""
    selectedclasssection = ""
    for i in config.selectedclass[::1]:
        listnum = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
        if i in listnum:
            selectedclassint += i
        else:
            selectedclasssection += i
    selectedclassint = int(selectedclassint)
    for i in S_Information:
        if selectedclassint == i.SClass and selectedclasssection == i.SSection:
            hno =  i.HouseInitial+"-"+str(i.HouseNumber)
            if i.SMiddleName == None:
                name =  i.SFirstName + " " + i.SLastName
            else:
                name =  i.SFirstName + " " + i.SMiddleName + " " + i.SLastName
            class_ = i.SClass
            section = i.SSection
            student = [hno, name, class_, section]
            config.students += [student]
    return render(request, "studentpage/studentpage.html", {"students": config.students, "max": today})

def submit_(request):
    '''S_Information = SInformation.objects.all()
    for i in S_Information:
        x = T-10846
        y = "att" + x
        at = request.GET[y]
        config.test += [at]'''
    x = "T-10876"
    y = request.GET[x]
    return HttpResponse(y)
