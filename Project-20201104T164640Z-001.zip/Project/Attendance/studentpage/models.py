from django.db import models

class SInformation(models.Model):
    HouseInitial = models.CharField(max_length=3)
    HouseNumber = models.IntegerField()
    SFirstName = models.CharField(max_length=50)
    SMiddleName = models.CharField(max_length=50, blank = True, null = True)
    SLastName = models.CharField(max_length=50)
    SClass = models.IntegerField()
    SSection = models.CharField(max_length=3)
    def __str__(self):
        return self.SFirstName

class SAttendance(models.Model):
    HouseNumber = models.ForeignKey(SInformation, on_delete=models.CASCADE)
    SFirstName = models.CharField(max_length=50)
    Date = models.DateField()
    Attendance = models.CharField(max_length=4)
    def __str__(self):
        return self.SFirstName