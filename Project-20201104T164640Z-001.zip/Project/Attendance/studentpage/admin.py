from django.contrib import admin

from .models import SAttendance
admin.site.register(SAttendance)

from .models import SInformation
admin.site.register(SInformation)